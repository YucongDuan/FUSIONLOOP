from __future__ import annotations
import argparse,json
from pathlib import Path
from .core import *

def emit(x):print(json.dumps(x,ensure_ascii=False,indent=2))
def readj(p):return json.loads(Path(p).read_text(encoding="utf-8"))

def main(argv=None):
    p=argparse.ArgumentParser(prog="fusionloop",description="Carbon-silicon symbiogenesis and hybrid capability continuity")
    sp=p.add_subparsers(dest="cmd",required=True)
    sp.add_parser("summary")
    x=sp.add_parser("assess");x.add_argument("profile")
    x=sp.add_parser("plan");x.add_argument("profile");x.add_argument("--out")
    x=sp.add_parser("breakthrough");x.add_argument("session")
    x=sp.add_parser("shock");x.add_argument("profile");x.add_argument("shock_id")
    x=sp.add_parser("passport");x.add_argument("profile");x.add_argument("--out")
    x=sp.add_parser("capsule");x.add_argument("session");x.add_argument("out_zip")
    x=sp.add_parser("vault-init");x.add_argument("path");x.add_argument("profile_id")
    x=sp.add_parser("vault-add");x.add_argument("path");x.add_argument("event_type");x.add_argument("payload_json")
    x=sp.add_parser("vault-verify");x.add_argument("path")
    sp.add_parser("selftest")
    a=p.parse_args(argv)
    if a.cmd=="summary":emit(summary())
    elif a.cmd=="assess":emit(assess(readj(a.profile)))
    elif a.cmd=="plan":
        r=build_loop(readj(a.profile));
        if a.out:Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
        emit(r)
    elif a.cmd=="breakthrough":emit(evaluate_breakthrough(readj(a.session)))
    elif a.cmd=="shock":emit(run_shock(readj(a.profile),a.shock_id))
    elif a.cmd=="passport":
        r=make_passport(readj(a.profile));
        if a.out:Path(a.out).write_text(json.dumps(r,ensure_ascii=False,indent=2),encoding="utf-8")
        emit(r)
    elif a.cmd=="capsule":emit(export_capsule(readj(a.session),a.out_zip))
    elif a.cmd=="vault-init":emit(init_vault(a.path,a.profile_id))
    elif a.cmd=="vault-add":emit(append_vault(a.path,a.event_type,json.loads(a.payload_json)))
    elif a.cmd=="vault-verify":emit(verify_vault(a.path))
    elif a.cmd=="selftest":
        r=selftest();emit(r);return 0 if r["passed"] else 1
    return 0
