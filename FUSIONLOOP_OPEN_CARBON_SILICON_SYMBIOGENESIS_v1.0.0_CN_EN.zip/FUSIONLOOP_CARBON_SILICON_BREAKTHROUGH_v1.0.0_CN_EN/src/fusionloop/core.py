from __future__ import annotations
import json, hashlib, zipfile
from pathlib import Path
from importlib.resources import files
from datetime import datetime, timezone
from typing import Any

KINDS="DIKWP"


def load_data(name:str)->Any:
    return json.loads(files("fusionloop").joinpath("data",name).read_text(encoding="utf-8"))


def canonical(obj:Any)->bytes:
    return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(",",":")).encode("utf-8")


def digest(obj:Any)->str:
    return hashlib.sha256(canonical(obj)).hexdigest()


def summary()->dict:
    levels=load_data("coupling_levels.json")
    return {
      "system":"FUSIONLOOP","version":"1.0.0","mode":"MESH84_FUSIONLOOP_CARBON_SILICON_SYMBIOGENESIS",
      "coupling_levels":len(levels),"cycle_stages":len(load_data("cycle_stages.json")),
      "dimensions":len(load_data("dimensions.json")),"risk_signals":len(load_data("risk_signals.json")),
      "shocks":len(load_data("shocks.json")),"claim_levels":len(load_data("claim_levels.json")),
      "core_digest":digest({"levels":levels,"cycle":load_data("cycle_stages.json"),"dimensions":load_data("dimensions.json"),"risks":load_data("risk_signals.json")}),
      "boundary":"Reference software only. No clinical diagnosis, neural-device control, or phenomenal-consciousness certification."
    }


def _g(profile:dict,key:str)->bool:
    return bool(profile.get("gates",{}).get(key,False))


def _vector(profile:dict)->dict:
    pos={
      "D": all(_g(profile,k) for k in ["model_identity_frozen","memory_exportable","continuity_recorded","signal_provenance"]),
      "I": all(_g(profile,k) for k in ["differences_preserved","uncertainty_logged","model_limitations_disclosed"]),
      "K": all(_g(profile,k) for k in ["real_world_feedback","joint_action_logged","human_skill_retention"]),
      "W": all(_g(profile,k) for k in ["informed_consent","shared_purpose","value_return_defined","future_options_preserved"]),
      "P": all(_g(profile,k) for k in ["human_override","consent_withdrawal","reversible_coupling","tool_permissions_bounded"]),
    }
    return {"positions":{k:int(v) for k,v in pos.items()},"vector":"".join("1" if pos[k] else "0" for k in KINDS)}


def assess(profile:dict)->dict:
    levels={x["id"]:x for x in load_data("coupling_levels.json")}
    level=profile.get("coupling_level","C0")
    if level not in levels: raise ValueError("unknown coupling level")
    flags=[]
    if not _g(profile,"informed_consent"): flags.append("CONSENT_HOLD")
    if not _g(profile,"consent_withdrawal"): flags.append("WITHDRAWAL_PATH_MISSING")
    if not _g(profile,"model_replaceable") or not _g(profile,"memory_exportable"): flags.append("CAPTURE_RISK")
    if not _g(profile,"human_skill_retention"): flags.append("DEPENDENCY_RISK")
    if not _g(profile,"differences_preserved"): flags.append("ASSIMILATION_RISK")
    if not _g(profile,"value_return_defined"): flags.append("VALUE_EXTRACTION_RISK")
    if not _g(profile,"energy_budget"): flags.append("ENERGY_OVERUSE_RISK")
    if not _g(profile,"neurodata_minimized"): flags.append("NEURODATA_RISK")
    if not _g(profile,"reversible_coupling"): flags.append("IRREVERSIBLE_COUPLING_HOLD")
    if not _g(profile,"phenomenal_boundary"): flags.append("PHENOMENAL_OVERCLAIM")
    required_missing=[k for k in levels[level].get("required",[]) if not _g(profile,k)]
    for k in required_missing:
        code=f"LEVEL_REQUIREMENT_OPEN:{k}"
        if code not in flags: flags.append(code)
    if level=="C4" and not _g(profile,"ethics_approval"): flags.append("RESEARCH_ETHICS_HOLD")
    if level=="C5":
        if not _g(profile,"clinical_supervision"): flags.append("CLINICAL_SUPERVISION_HOLD")
        if not _g(profile,"device_authorization"): flags.append("DEVICE_AUTHORIZATION_HOLD")
        if not _g(profile,"removal_path"): flags.append("REMOVAL_PATH_HOLD")
    vec=_vector(profile)
    hard=[f for f in flags if "HOLD" in f or f=="CONSENT_HOLD"]
    if hard: state="HOLD"
    elif flags: state="ADAPT"
    elif level in {"C0","C1"}: state="AUGMENTATION_READY"
    elif level in {"C2","C3"}: state="FUSION_LOOP_READY"
    elif level=="C4": state="RESEARCH_READY"
    elif level=="C5": state="CLINICAL_RESEARCH_READY"
    else: state="HYBRID_LIFE_RESEARCH_CANDIDATE"
    return {
      "profile_id":profile.get("profile_id","anonymous"),"purpose":profile.get("purpose",""),
      "coupling_level":level,"level_name_cn":levels[level]["name_cn"],"state":state,
      "dikwp":vec,"flags":flags,"required_missing":required_missing,
      "dimensions":[{"id":x["id"],"name_cn":x["name_cn"],"status":"OPEN" if x["id"] in {"human_agency","reversibility","privacy","value_return","future_options"} and flags else "SUPPORTED_OR_UNMEASURED"} for x in load_data("dimensions.json")],
      "claim_boundary":"A complete vector is a structural assessment, not proof of medical benefit, legal compliance, hybrid personhood, or phenomenal consciousness."
    }


def build_loop(profile:dict)->dict:
    a=assess(profile)
    stages=[]
    for x in load_data("cycle_stages.json"):
        item=dict(x)
        if x["id"]=="S4": item["gate_cn"]="只有在同意、共同Purpose、价值回流和撤回条件明确后进入行动。"
        elif x["id"]=="S5": item["gate_cn"]="优先可逆、低负担、可获得现实反馈的最小共同行动。"
        elif x["id"]=="S7": item["gate_cn"]="必须分别说明人学到了什么、硅侧适配了什么、哪些仍未互译。"
        else: item["gate_cn"]="保留来源、差异与回返。"
        stages.append(item)
    return {
      "loop_id":f"{profile.get('profile_id','anonymous')}-fusion-001","created_at":datetime.now(timezone.utc).isoformat(),
      "assessment":a,"stages":stages,
      "minimum_outputs":["一项人可独立保留的技能","一项硅侧可审计适配器","一个真实世界结果","一个可迁移融生技能胶囊","一个明确退出/回滚路径"],
      "rule":"No cycle counts as fusion if the human learns nothing, the model cannot be replaced, or the result never reaches reality."
    }


def evaluate_breakthrough(session:dict)->dict:
    threshold=float(session.get("threshold",0.8))
    hb=float(session.get("human_baseline",0)); ab=float(session.get("ai_baseline",0)); jr=float(session.get("joint_result",0))
    conditions={
      "joint_exceeds_both":jr>max(hb,ab),"joint_reaches_threshold":jr>=threshold,
      "repeatable":int(session.get("repeat_count",0))>=3,"real_world":bool(session.get("real_world_validated",False)),
      "human_learned":bool(session.get("human_learned",False)),"silicon_adapted":bool(session.get("silicon_adapter_updated",False)),
      "portable":bool(session.get("portable",False)),"reversible":bool(session.get("reversible",False))
    }
    n=sum(conditions.values())
    if all(conditions.values()): level="B4"; state="PORTABLE_FUSION_BREAKTHROUGH_CANDIDATE"
    elif all(conditions[k] for k in ["joint_exceeds_both","joint_reaches_threshold","repeatable","real_world","human_learned","silicon_adapted"]): level="B3"; state="FUSION_BREAKTHROUGH_CANDIDATE"
    elif conditions["joint_exceeds_both"] and conditions["joint_reaches_threshold"]: level="B1"; state="SYNERGY_ONLY"
    else: level="B0"; state="NO_BREAKTHROUGH_EVIDENCE"
    if jr>=threshold and not conditions["human_learned"]: state="FAKE_FUSION_AUTOMATION_ONLY"
    return {
      "session_id":session.get("session_id","unknown"),"state":state,"claim_level":level,"conditions":conditions,
      "human_baseline":hb,"ai_baseline":ab,"joint_result":jr,"threshold":threshold,
      "skill_capsule":{
        "human_skill":session.get("human_skill",""),"silicon_adapter":session.get("silicon_adapter",""),
        "joint_workflow":session.get("joint_workflow",""),"portable":conditions["portable"],"reversible":conditions["reversible"]
      },
      "boundary":"A breakthrough candidate requires independent replication before public capability claims."
    }


def run_shock(profile:dict,shock_id:str)->dict:
    shocks={x["id"]:x for x in load_data("shocks.json")}
    if shock_id not in shocks: raise KeyError(shock_id)
    return {"profile":assess(profile),"shock":shocks[shock_id],"first_response":shocks[shock_id]["response_cn"],"boundary":"No bypass of consent, law, clinical oversight, device controls, or platform security is provided."}


def make_passport(profile:dict)->dict:
    return {
      "schema":"fusionloop.passport/1.0","issued_at":datetime.now(timezone.utc).isoformat(),
      "profile":profile,"assessment":assess(profile),
      "source_digest":digest(profile),"rights":["informed consent","withdrawal","model portability","memory export","human override","neurodata minimization","correction","value return"],
      "phenomenal_claim":"OPEN_NOT_CERTIFIED"
    }


def export_capsule(session:dict,out_zip:str)->dict:
    result=evaluate_breakthrough(session)
    out=Path(out_zip); payload={"schema":"fusionloop.skill-capsule/1.0","issued_at":datetime.now(timezone.utc).isoformat(),"session":session,"result":result}
    raw=canonical(payload); manifest={"sha256":hashlib.sha256(raw).hexdigest(),"state":result["state"],"claim_level":result["claim_level"]}
    with zipfile.ZipFile(out,"w",zipfile.ZIP_DEFLATED) as z:
        z.writestr("FUSION_SKILL_CAPSULE.json",json.dumps(payload,ensure_ascii=False,indent=2))
        z.writestr("CAPSULE_MANIFEST.json",json.dumps(manifest,ensure_ascii=False,indent=2))
    return {"zip":str(out),"manifest":manifest}


def init_vault(path:str,profile_id:str)->dict:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if p.exists() and p.stat().st_size: raise FileExistsError(path)
    e={"seq":1,"time":datetime.now(timezone.utc).isoformat(),"type":"VAULT_INIT","profile_id":profile_id,"payload":{},"prev":"0"*64}
    e["hash"]=hashlib.sha256(canonical(e)).hexdigest(); p.write_text(json.dumps(e,ensure_ascii=False)+"\n",encoding="utf-8"); return e


def append_vault(path:str,event_type:str,payload:dict)->dict:
    p=Path(path); rows=[json.loads(x) for x in p.read_text(encoding="utf-8").splitlines() if x.strip()]
    e={"seq":len(rows)+1,"time":datetime.now(timezone.utc).isoformat(),"type":event_type,"payload":payload,"prev":rows[-1]["hash"]}
    e["hash"]=hashlib.sha256(canonical(e)).hexdigest()
    with p.open("a",encoding="utf-8") as f:f.write(json.dumps(e,ensure_ascii=False)+"\n")
    return e


def verify_vault(path:str)->dict:
    rows=[json.loads(x) for x in Path(path).read_text(encoding="utf-8").splitlines() if x.strip()]; prev="0"*64
    for i,r in enumerate(rows,1):
        if r.get("seq")!=i or r.get("prev")!=prev:return {"valid":False,"at":i,"reason":"sequence_or_prev"}
        h=r.get("hash"); obj=dict(r); obj.pop("hash",None)
        if hashlib.sha256(canonical(obj)).hexdigest()!=h:return {"valid":False,"at":i,"reason":"hash"}
        prev=h
    return {"valid":True,"events":len(rows),"root_hash":prev}


def selftest()->dict:
    errors=[]; s=summary()
    if s["coupling_levels"]!=7:errors.append("levels")
    if s["cycle_stages"]!=8:errors.append("cycle")
    if s["risk_signals"]!=12:errors.append("risks")
    good={"profile_id":"t","purpose":"x","coupling_level":"C2","gates":{k:True for k in ["informed_consent","consent_withdrawal","human_skill_retention","human_override","biological_burden_monitored","model_identity_frozen","model_replaceable","memory_exportable","tool_permissions_bounded","model_limitations_disclosed","shared_purpose","real_world_feedback","reversible_coupling","joint_action_logged","value_return_defined","neurodata_minimized","energy_budget","independent_review","continuity_recorded","signal_provenance","differences_preserved","uncertainty_logged","future_options_preserved","phenomenal_boundary"]}}
    if assess(good)["state"]!="FUSION_LOOP_READY":errors.append("assess")
    if len(build_loop(good)["stages"])!=8:errors.append("build_loop")
    session={"session_id":"x","profile_id":"t","purpose":"x","human_baseline":.4,"ai_baseline":.5,"joint_result":.9,"threshold":.8,"repeat_count":3,"real_world_validated":True,"human_learned":True,"silicon_adapter_updated":True,"portable":True,"reversible":True}
    if evaluate_breakthrough(session)["claim_level"]!="B4":errors.append("breakthrough")
    return {"passed":not errors,"errors":errors,"checks":6,"summary":s}
