# Code of Conduct

Respect consent, autonomy, evidence, criticism, and the non-instrumental status of participants.
