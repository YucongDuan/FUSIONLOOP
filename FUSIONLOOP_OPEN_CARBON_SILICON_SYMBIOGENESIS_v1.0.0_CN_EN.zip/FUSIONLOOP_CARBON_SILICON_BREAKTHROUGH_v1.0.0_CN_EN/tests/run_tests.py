import sys,json,tempfile
from pathlib import Path
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/"src"))
from fusionloop.core import *

t=[]
def ck(n,c):t.append((n,bool(c)))
ck("summary",summary()["coupling_levels"]==7 and summary()["cycle_stages"]==8)
p=json.loads((root/"examples/profiles/knowledge_partner.json").read_text(encoding="utf-8"))
ck("assess",assess(p)["state"]=="FUSION_LOOP_READY")
ck("loop",len(build_loop(p)["stages"])==8)
s=json.loads((root/"examples/sessions/breakthrough_candidate.json").read_text(encoding="utf-8"))
ck("breakthrough",evaluate_breakthrough(s)["claim_level"]=="B4")
f=json.loads((root/"examples/sessions/fake_fusion.json").read_text(encoding="utf-8"))
ck("fake",evaluate_breakthrough(f)["state"]=="FAKE_FUSION_AUTOMATION_ONLY")
with tempfile.TemporaryDirectory() as d:
    v=Path(d)/"v.jsonl";init_vault(str(v),"p");append_vault(str(v),"TEST",{"x":1});ck("vault",verify_vault(str(v))["valid"])
ck("selftest",selftest()["passed"])
for n,v in t:print(("PASS" if v else "FAIL"),n)
print(sum(v for _,v in t),"passed,",sum(not v for _,v in t),"failed")
raise SystemExit(0 if all(v for _,v in t) else 1)
