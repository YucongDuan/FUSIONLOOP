# Security

Do not submit real neural data, biometric identifiers, credentials, or private health records in public issues. Report security concerns privately.
