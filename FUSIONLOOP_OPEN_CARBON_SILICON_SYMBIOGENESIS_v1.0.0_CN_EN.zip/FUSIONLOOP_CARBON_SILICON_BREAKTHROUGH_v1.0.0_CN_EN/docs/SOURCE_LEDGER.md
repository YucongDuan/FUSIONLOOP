# Source Ledger / 来源账本

- [S01] **用户提供的野牛生态恢复视频页面** (inspiration-only) — 仅作为循环与关键功能回归的启发，不把页面标题中的数字当作科学证据。 — https://mbd.baidu.com/newspage/data/videolanding?nid=sv_3138703022235575149&sourceFrom=share
- [S02] **UNESCO Recommendation on the Ethics of Neurotechnology** (official) — 2025年通过的全球神经技术伦理规范，强调人权、尊严、心理隐私、自主和社会福祉。 — https://www.unesco.org/en/legal-affairs/recommendation-ethics-neurotechnology
- [S03] **UNESCO adopts first global standard on neurotechnology ethics** (official) — 说明推荐书的全球规范定位与保护目标。 — https://www.unesco.org/en/articles/ethics-neurotechnology-unesco-adopts-first-global-standard-cutting-edge-technology
- [S04] **OECD Recommendation on Responsible Innovation in Neurotechnology** (official) — 强调安全评估、包容、社会讨论、监督能力和脑数据保护。 — https://legalinstruments.oecd.org/api/print?Lang=en&ids=658
- [S05] **FDA Guidance: Implanted BCI Devices** (official) — 植入式BCI从研究到市场的非临床与临床考虑。 — https://www.fda.gov/regulatory-information/search-fda-guidance-documents/implanted-brain-computer-interface-bci-devices-patients-paralysis-or-amputation-non-clinical-testing
- [S06] **NIH BRAIN 2.0 Neuroethics** (official) — 神经技术可能触及思想、情绪、身份和记忆，应进行持续前瞻伦理评估。 — https://www.nih.gov/brain/about/vision/brain-20-neuroethics-enabling-enhancing-neuroscience-advances-society
- [S07] **Brain Imaging Data Structure (BIDS)** (standard) — 神经影像和EEG等研究数据的社区标准与可复现生态。 — https://bids.neuroimaging.io/index.html
- [S08] **Open mHealth** (standard) — 可穿戴与移动健康数据互操作参考。 — https://www.openmhealth.org/
- [S09] **Symbiotic AI: Augmenting Human Cognition from PCs to Cars** (research) — 讨论维持人作为主要行动者、认知增强与人机协同。 — https://arxiv.org/html/2504.03105v1
- [S10] **Augmenting Human Cognition With Generative AI** (research) — 强调增强而非替代人的认知，并从AI辅助决策总结设计经验。 — https://www.medien.ifi.lmu.de/pubdb/publications/pub/zhangt2025chi-workshop/zhangt2025chi-workshop.pdf
- [S11] **FDA/NIH Workshop on Implanted BCI Clinical Outcome Assessments** (official) — BCI效益与风险需要患者、研究者、临床、监管和支付方共同评估。 — https://www.fda.gov/media/182567/download
