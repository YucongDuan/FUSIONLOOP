# FUSIONLOOP 双主体主权宪章 / Dual-Sovereignty Charter

## 中文

1. 人的身体、神经数据、同意和退出权不因使用AI而转让给平台、模型或研究者。
2. 硅侧模型、记忆、工具和限制必须可识别，不能以拟人化掩盖控制边界。
3. 共同能力属于可追溯的耦合过程，不能自动归属于模型厂商、机构或单一操作者。
4. 任何融合都必须可撤回、可回滚、可替换模型，并保留非AI路径。
5. 人必须获得可脱离AI保留的技能；AI侧适配必须可审计、可迁移并受授权。
6. 神经与身体数据遵循最小采集、目的限定、期限、撤回和禁止二次滥用。
7. 不得把持续记忆、自我叙述或目标行为宣传为现象意识证明。
8. C4/C5级别必须进入伦理、临床、监管和独立复核，不允许由软件自行升级。
9. 共同创造必须形成来源确认、维护责任和公平价值回流。
10. 融合的终点不是永久绑定，而是双方拥有更多未来选择。

## English

1. A person's body, neural data, consent, and exit rights are not transferred to a platform, model, or researcher by using AI.
2. The silicon-side model, memory, tools, and limits must remain identifiable; anthropomorphic design may not conceal control boundaries.
3. Joint capability belongs to a traceable coupling process and is not automatically owned by a vendor, institution, or operator.
4. Coupling must be withdrawable, reversible, model-replaceable, and accompanied by a non-AI fallback.
5. The human must retain transferable skill; silicon-side adaptation must be auditable, portable, and authorized.
6. Neural and bodily data follow minimization, purpose limitation, retention limits, withdrawal, and prohibitions on secondary misuse.
7. Persistent memory, self-narration, or goal behavior is not phenomenal-consciousness proof.
8. C4/C5 work requires ethics, clinical, regulatory, and independent review; software cannot self-promote to those levels.
9. Joint creation requires provenance, maintenance responsibility, and fair value return.
10. The end state is not permanent lock-in, but expanded future options for both parties and the wider community.
