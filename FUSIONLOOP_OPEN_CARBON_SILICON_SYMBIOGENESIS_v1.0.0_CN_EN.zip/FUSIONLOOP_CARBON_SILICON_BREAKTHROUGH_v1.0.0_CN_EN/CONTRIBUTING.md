# Contributing

Contributions should separate factual claims, reference implementation, research hypotheses, and clinical or regulatory requirements.
