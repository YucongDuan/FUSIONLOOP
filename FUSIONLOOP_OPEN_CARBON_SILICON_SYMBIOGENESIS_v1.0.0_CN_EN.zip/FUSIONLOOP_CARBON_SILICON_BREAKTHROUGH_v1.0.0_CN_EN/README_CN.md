# FUSIONLOOP｜融生环

**碳硅融生突破循环、双主体主权与混合能力连续开源系统**

> 不是让人更像机器，也不是让机器伪装成人；而是让新的能力在碳与硅之间出生，并能够被携带、纠正和共同治理。

版本：1.0.0  
模式：`MESH84_FUSIONLOOP_CARBON_SILICON_SYMBIOGENESIS`  
许可：Apache-2.0

## 为什么不是 REGENLOOP 的重复

REGENLOOP 关注 AI 如何帮助个人恢复能力、关系和选择；FUSIONLOOP 进一步研究：当人和 AI 长期互适应、身体信号或神经接口逐步进入闭环时，怎样产生单独一方都没有的新能力，同时不把人锁进平台、不把 AI 伪装成人，也不删除二者之间真实差异。

## 快速运行

```bash
python dist/FusionLoop.pyz summary
python dist/FusionLoop.pyz assess examples/profiles/knowledge_partner.json
python dist/FusionLoop.pyz plan examples/profiles/wearable_creator.json --out cycle.json
python dist/FusionLoop.pyz breakthrough examples/sessions/breakthrough_candidate.json
python dist/FusionLoop.pyz shock examples/profiles/eeg_research.json SH_SENSOR_DRIFT
python dist/FusionLoop.pyz passport examples/profiles/knowledge_partner.json --out passport.json
python dist/FusionLoop.pyz capsule examples/sessions/breakthrough_candidate.json skill_capsule.zip
python dist/FusionLoop.pyz selftest
```

直接打开 `site/index.html` 可使用离线工作台。

## 关键边界

- 参考实现不控制任何真实神经设备、医疗器械、机器人或人体干预。
- C4/C5 只用于研究与临床治理建模，不能替代伦理、医疗、监管和专业判断。
- `11111` 只表示 D/I/K/W/P 结构义务，不证明疗效、人格或现象意识。
- 真实神经、健康和身份数据不应上传到公共仓库。
